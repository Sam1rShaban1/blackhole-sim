{-# LANGUAGE RecordWildCards #-}

import Graphics.UI.GLUT
import System.Random
import Data.IORef
import Control.Monad (forM, forM_)

-- Differentiates between the various components of our simulation
data ParticleType = Disk | Halo | PhotonRing | Star
  deriving (Eq, Show)

-- Particle structure holds all necessary information
data Particle = Particle
  { pPos    :: !(Vertex3 GLfloat)
  , pVel    :: !(Vector3 GLfloat)
  , pColor  :: !(Color3 GLfloat)
  , pRadius :: !GLfloat -- The particle's orbital radius
  , pSpeed  :: !GLfloat
  , pType   :: !ParticleType
  }

-- Simulation Constants (tweak these to change the look)
numDiskParticles :: Int
numDiskParticles = 10000

numHaloParticles :: Int
numHaloParticles = 7000

numPhotonRingParticles :: Int
numPhotonRingParticles = 2000

numStars :: Int
numStars = 500

-- Radii defining the structure
diskRadiusMin, diskRadiusMax, photonRingRadius :: GLfloat
diskRadiusMin = 3.0
diskRadiusMax = 15.0
photonRingRadius = diskRadiusMin - 0.1

-- Helper to interpolate between two colors. t=0 is colorA, t=1 is colorB.
lerpColor :: GLfloat -> Color3 GLfloat -> Color3 GLfloat -> Color3 GLfloat
lerpColor t (Color3 r1 g1 b1) (Color3 r2 g2 b2) =
  let lerp v1 v2 = v1 * (1-t) + v2 * t
  in Color3 (lerp r1 r2) (lerp g1 g2) (lerp b1 b2)

-- Generates a color based on distance from the center (hot white -> cool orange)
getColorForDistance :: GLfloat -> Color3 GLfloat
getColorForDistance r =
  let hotColor  = Color3 1.0 1.0 0.85 -- Bright, slightly yellow white
      coolColor = Color3 1.0 0.5 0.1  -- Dusty orange
      t = max 0.0 . min 1.0 $ (r - diskRadiusMin) / (diskRadiusMax - diskRadiusMin)
  in lerpColor t hotColor coolColor

-- Generic particle generator
genParticles :: Int -> ParticleType -> IO [Particle]
genParticles count pType = forM [1..count] $ \_ -> do
    r <- case pType of
        Disk -> randomRIO (diskRadiusMin, diskRadiusMax)
        Halo -> randomRIO (diskRadiusMin, diskRadiusMax * 0.9) -- Halo is slightly smaller
        PhotonRing -> return photonRingRadius
        Star -> randomRIO (50, 100) -- Distant stars

    angle <- randomRIO (0, 2*pi)
    
    (pos, speed) <- case pType of
        Disk -> do
            z <- randomRIO (-0.15, 0.15)
            s <- randomRIO (0.008, 0.025)
            return (Vertex3 (r * cos angle) (r * sin angle) z, s)
        Halo -> do
            y <- randomRIO (-0.15, 0.15)
            s <- randomRIO (0.008, 0.025)
            return (Vertex3 (r * cos angle) y (r * sin angle), s)
        PhotonRing -> do
            s <- randomRIO (0.03, 0.035) -- Faster
            return (Vertex3 (r * cos angle) (r * sin angle) 0, s)
        Star -> do
            angle2 <- randomRIO (0, 2*pi)
            let (x,y,z) = (r * cos angle * sin angle2, r * sin angle * sin angle2, r * cos angle2)
            return (Vertex3 x y z, 0) -- Stars don't move

    let color = case pType of
            PhotonRing -> Color3 1.0 1.0 0.9
            Star       -> let c = 0.5 in Color3 c c c
            _          -> getColorForDistance r
            
    return $ Particle pos (Vector3 0 0 0) color r speed pType

-- Update particle positions based on simplified orbital mechanics
updateParticle :: Particle -> Particle
updateParticle p@Particle{..} | pType == Star = p -- Stars are static
updateParticle p@Particle{..} =
    let Particle { pPos = Vertex3 px py pz, .. } = p
        -- Keplarian motion: faster closer to the center
        theta = pSpeed / (pRadius * pRadius)
    in case pType of
      -- Disk & PhotonRing particles orbit in the XY plane (around Z axis)
      Disk -> let x' = px * cos theta - py * sin theta
                  y' = px * sin theta + py * cos theta
              in p { pPos = Vertex3 x' y' pz }
      PhotonRing -> let x' = px * cos theta - py * sin theta
                        y' = px * sin theta + py * cos theta
                    in p { pPos = Vertex3 x' y' pz }
      -- Halo particles orbit in the XZ plane (around Y axis)
      Halo -> let x' = px * cos theta - pz * sin theta
                  z' = px * sin theta + pz * cos theta
              in p { pPos = Vertex3 x' py z' }
      _ -> p

-- Render a single particle
renderParticle :: Vertex3 GLfloat -> Particle -> IO ()
renderParticle camPos p@Particle{..} =
  let Particle { pPos = Vertex3 px py _, pColor = Color3 r g b, .. } = p
      (brightness, dopplerColor) = case pType of
        Disk ->
          -- Fake Doppler beaming: side moving toward camera is brighter/bluer
          let sideFactor = -py / pRadius -- proxy for velocity component toward camera at (0,0,Z)
              brightnessMod = 1.0 + sideFactor * 0.7 -- Increase brightness up to 70%
              blueShift = max 0 $ sideFactor * 0.5
          in (brightnessMod, Color3 r (g + blueShift*0.5) (b + blueShift))
        _ -> (1.0, pColor) -- No effect for other types

  in preservingMatrix $ do
      color $ dopplerColor `multC` brightness
      translate (pPos :: Vertex3 GLfloat)
      renderPrimitive Points $ vertex (Vertex3 0 0 0 :: Vertex3 GLfloat)
  where
    multC (Color3 r g b) s = Color3 (r*s) (g*s) (b*s)

-- Main display callback
display :: IORef [Particle] -> IORef GLfloat -> DisplayCallback
display particlesRef camAngleRef = do
    clear [ColorBuffer, DepthBuffer]
    loadIdentity

    camAngle <- get camAngleRef
    let camRadius = 30.0
        camPos = Vertex3 (camRadius * sin camAngle) 2.5 (camRadius * cos camAngle)
    lookAt camPos (Vertex3 0 0 0) (Vector3 0 1 0)

    -- Render the central black hole shadow
    color (Color3 0 0 0 :: Color3 GLfloat)
    renderObject Solid (Sphere' (diskRadiusMin - 0.2) 32 32)

    -- Render all particles
    particles <- get particlesRef
    forM_ particles (renderParticle camPos)

    swapBuffers

-- Idle callback for animation
idle :: IORef [Particle] -> IORef GLfloat -> IdleCallback
idle particlesRef camAngleRef = do
    modifyIORef' particlesRef (map updateParticle)
    modifyIORef' camAngleRef (+0.0015) -- Camera orbit speed
    postRedisplay Nothing

-- Reshape callback
reshape :: ReshapeCallback
reshape size@(Size w h) = do
    viewport $= (Position 0 0, size)
    matrixMode $= Projection
    loadIdentity
    perspective 45 (fromIntegral w / fromIntegral h) 1.0 200.0
    matrixMode $= Modelview 0

-- Main function
main :: IO ()
main = do
    (_progName, _args) <- getArgsAndInitialize
    initialDisplayMode $= [DoubleBuffered, RGBAMode, WithDepthBuffer]
    _window <- createWindow "Gargantua Simulation in Haskell"
    windowSize $= Size 1600 900

    -- OpenGL settings for a glowing, volumetric look
    clearColor $= Color4 0 0 0 1
    depthFunc $= Just Less
    blend $= Enabled
    blendFunc $= (SrcAlpha, One) -- Additive blending is key for the glow
    pointSize $= 1.5
    pointSmooth $= Enabled

    -- Generate all particle types
    diskParticles <- genParticles numDiskParticles Disk
    haloParticles <- genParticles numHaloParticles Halo
    photonParticles <- genParticles numPhotonRingParticles PhotonRing
    starParticles <- genParticles numStars Star
    let allParticles = diskParticles ++ haloParticles ++ photonParticles ++ starParticles

    particlesRef <- newIORef allParticles
    camAngleRef <- newIORef 0.0

    displayCallback $= display particlesRef camAngleRef
    idleCallback $= Just (idle particlesRef camAngleRef)
    reshapeCallback $= Just reshape

    mainLoop
